//
//  Crisis_gameApp.swift
//  Crisis game
//
//  Created by 吴征航 on 2024/2/12.
//

import SwiftUI

@main
struct Crisis_gameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
